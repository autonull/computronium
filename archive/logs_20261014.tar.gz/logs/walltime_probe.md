# Measured test walltime

15 tests with no declared budget, slowest first.
Regenerate with `pytest --walltime-report=<path>`.

| seconds | nodeid |
|---:|---|
| 28.98 | `tests/property/test_undefined_name_lock.py::test_every_cross_module_import_names_a_defined_symbol` |
| 1.65 | `tests/property/test_undefined_name_lock.py::test_hand_written_getattr_modules_resolve_exactly_one_name` |
| 0.18 | `tests/property/test_settling.py::test_inf_norm_converged_false_before_early_start` |
| 0.14 | `tests/property/test_settling.py::test_inf_norm_converged_detects_convergence` |
| 0.14 | `tests/property/test_undefined_name_lock.py::test_undefined_name_is_never_suppressed` |
| 0.06 | `tests/property/test_settling.py::test_settle_single_state_trajectory_length` |
| 0.05 | `tests/property/test_undefined_name_lock.py::test_no_undefined_names_in_tree` |
| 0.03 | `tests/property/test_undefined_name_lock.py::test_getattr_population_is_enumerated` |
| 0.03 | `tests/property/test_settling.py::test_settle_single_state_returns_dynamics` |
| 0.02 | `tests/property/test_settling.py::test_settle_activations_list_convergence` |
| 0.01 | `tests/property/test_undefined_name_lock.py::test_every_known_blocked_file_still_blocks_for_the_stated_reason` |
| 0.00 | `tests/property/test_undefined_name_lock.py::test_scanned_roots_exist[computronium]` |
| 0.00 | `tests/property/test_undefined_name_lock.py::test_scanned_roots_exist[packages]` |
| 0.00 | `tests/property/test_undefined_name_lock.py::test_scanned_roots_exist[tests]` |
| 0.00 | `tests/property/test_undefined_name_lock.py::test_scanned_roots_exist[scripts]` |
