# Continuous Experiment Report

- **cycle**: 7
- **best accuracy**: 0.9580
- **store**: `experiments/continuous/continuous.duckdb`

## Last cycle
- kind: explore  fidelity: L0
- cells measured: 13  failures: 0
- empty space: False

## Top cells

| acc | substrate | geometry | dynamics | credit | update | plasticity |
|----:|---|---|---|---|---|---|
| 0.9580 | memristive | tile_mesh | instantaneous | target_inversion | ortho_adam | conflict_adaptive |
| 0.9530 | optical | tile_mesh | instantaneous | target_inversion | ortho_adam | conflict_adaptive |
| 0.9530 | memristive | tile_mesh | energy_minimization | target_inversion | ortho_adam | routing |
| 0.9250 | optical | tile_mesh | instantaneous | target_inversion | ortho_adam | routing |
| 0.8500 | ternary | tile_mesh | instantaneous | target_inversion | euclidean | routing |
| 0.5611 | complex | tile_mesh | energy_minimization | target_inversion | euclidean | routing |
| 0.5361 | memristive | tile | instantaneous | target_inversion | euclidean | routing |
| 0.2611 | memristive | tile_mesh | energy_minimization | target_inversion | lion | routing |
| 0.2167 | ternary | tile | instantaneous | target_inversion | ortho_adam | rule_state |
| 0.1861 | ternary | tile | energy_minimization | homeostatic | euclidean | conflict_adaptive |

## Cycle history

| cycle | kind | best | Δ | cells | empty |
|------:|------|-----:|--:|------:|-------|
| 0 | explore | 0.9580 | +0.9580 | 10 | False |
| 1 | exploit | 0.9580 | +0.0000 | 10 | False |
| 2 | explore | 0.9580 | +0.0000 | 10 | False |
| 3 | exploit | 0.9580 | +0.0000 | 13 | False |
| 4 | explore | 0.9580 | +0.0000 | 10 | False |
| 5 | exploit | 0.9580 | +0.0000 | 10 | False |
| 6 | explore | 0.9580 | +0.0000 | 13 | False |
