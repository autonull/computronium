# Autonomous Experiment Report

- **cycle**: 8
- **best accuracy**: 0.9806
- **store**: `experiments/autonomous/autonomous.duckdb`

## Last cycle
- kind: exploit  fidelity: L1
- cells measured: 50  failures: 0
- empty space: False

## Top cells

| acc | substrate | geometry | dynamics | credit | update | plasticity |
|----:|---|---|---|---|---|---|
| 0.9806 | sparse | feedforward | instantaneous | gradient | ortho_adam | substrate_coupled |
| 0.9500 | sparse | feedforward | error_predictive_coding | thermodynamic_contrast | ortho_adam | fast_weights |
| 0.9083 | sparse | feedforward | instantaneous | pepita | ortho_adam | substrate_coupled |
| 0.9028 | complex | feedforward | error_predictive_coding | thermodynamic_contrast | riemannian_orthogonal | temporal_psi |
| 0.9028 | complex | recurrent | energy_minimization | gradient | riemannian_orthogonal | routing |
| 0.8972 | sparse | feedforward | lazy | thermodynamic_contrast | ortho_adam | rule_state |
| 0.8861 | digital | feedforward | spike_integration | target_inversion | riemannian_orthogonal | fast_weights |
| 0.8556 | ternary | tile_mesh | instantaneous | target_inversion | ortho_adam | null |
| 0.7861 | sparse | feedforward | error_predictive_coding | thermodynamic_contrast | ortho_adam | null |
| 0.7806 | complex | recurrent | instantaneous | random_projections | muon | rule_state |
| 0.7778 | optical | tile | instantaneous | target_inversion | natural_gradient | routing |
| 0.7639 | analog | recurrent | instantaneous | random_projections | local_adam | substrate_coupled |
| 0.7528 | analog | tile_mesh | instantaneous | target_inversion | riemannian_orthogonal | null |
| 0.7528 | digital | recurrent | energy_minimization | target_inversion | riemannian_orthogonal | rule_state |
| 0.7444 | sparse | tile_mesh | instantaneous | target_inversion | muon | null |
| 0.7417 | sparse | feedforward | spike_integration | target_inversion | muon | routing |
| 0.7389 | complex | feedforward | error_predictive_coding | local_goodness | riemannian_orthogonal | null |
| 0.7278 | optical | feedforward | energy_minimization | target_inversion | ortho_adam | rule_state |
| 0.7139 | optical | feedforward | lazy | local_goodness | riemannian_orthogonal | null |
| 0.7028 | analog | feedforward | instantaneous | target_inversion | ortho_adam | routing |

## Cycle history

| cycle | kind | best | Δ | cells | empty |
|------:|------|-----:|--:|------:|-------|
| 0 | explore | 0.7861 | +0.7861 | 170 | False |
| 1 | exploit | 0.9500 | +0.1639 | 50 | False |
| 2 | explore | 0.9500 | +0.0000 | 186 | False |
| 3 | exploit | 0.9806 | +0.0306 | 49 | False |
| 4 | explore | 0.9806 | +0.0000 | 174 | False |
| 5 | exploit | 0.9806 | +0.0000 | 45 | False |
| 6 | explore | 0.9806 | +0.0000 | 160 | False |
| 7 | exploit | 0.9806 | +0.0000 | 50 | False |
